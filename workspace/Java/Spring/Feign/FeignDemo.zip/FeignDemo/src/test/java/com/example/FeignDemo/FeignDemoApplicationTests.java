package com.example.FeignDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
